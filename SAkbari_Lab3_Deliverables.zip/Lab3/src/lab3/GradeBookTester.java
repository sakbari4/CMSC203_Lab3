package lab3;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;



class GradeBookTester {
	private GradeBook gradeBook1;
	private GradeBook gradeBook2;

	@BeforeEach
	void setUp() throws Exception {
		gradeBook1 = new GradeBook(5);
		gradeBook2 = new GradeBook(5);
		gradeBook1.addScore(10);
		gradeBook1.addScore(33);
		gradeBook2.addScore(69);
		gradeBook2.addScore(77);
	}

	@AfterEach
	void tearDown() throws Exception {
		gradeBook1 = null;
		gradeBook2 = null;
	}

	@Test
	void testAddScore() {
		assertTrue(gradeBook1.toString().equals("10.0 33.0 "));
		assertEquals(2, gradeBook1.getScoreSize());
	}

	@Test
	void testSum() {
		assertEquals(43, gradeBook1.sum(), 0.0001);
	}

	@Test
	void testMinimum() {
		assertEquals(10, gradeBook1.minimum(), 0.001);
	}

	@Test
	void testFinalScore() {
		assertEquals(33, gradeBook1.finalScore(), 0.0001);
	}

	@Test
	void testGetScoreSize() {
		fail("Not yet implemented");
	}

	@Test
	void testToString() {
		fail("Not yet implemented");
	}

}
